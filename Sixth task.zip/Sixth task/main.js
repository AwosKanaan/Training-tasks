var grid = document.getElementById("grid");
var test = false;

var flagsCount = 0;
var numberOfMines = 20;

var minesLocations = [];

function generateGrid() {
    // Can be adjusted to get a parameter of cols and rows

    grid.innerHTML = "";

    for (var i = 0; i < 10; i++) {
        var row = grid.insertRow(i);

        for (var j = 0; j < 10; j++) {
            var cell = row.insertCell(j);
            cell.onclick = function() { clickCell(this) };
            cell.oncontextmenu = function(e) {e.preventDefault(); toggleFlag(this)};
            var mine = document.createAttribute("mine");
            mine.value = "false";
            cell.setAttributeNode(mine);
        }

    }
    addMines();
    revealMines();
}

function addMines() {
    // Can be adjusted to get a parameter of number of bombs based on difficulty -- FOR FUTURE WORK --
    for (var i = 0; i < numberOfMines; i++) {
        var row = Math.floor(Math.random() * 10);
        var column = Math.floor(Math.random() * 10);
        var cell = grid.rows[row].cells[column];
        if (cell.getAttribute("mine") == "false") {
            cell.setAttribute("mine", "true");
        } else {
            i--;
            continue;
        }

        minesLocations.push({row: row , column : column});
    }
}

function clickCell(cell) {
    //CHeck if the user clicked on a mine

    if (cell.getAttribute("mine") == "true") {
        revealMines();
        alert("Game Over");
    } else {
        cell.className = "clicked";
    
        // count nearby mines
        var minesCount = countNearbyMines(cell);

        var cellRow = cell.parentNode.rowIndex;
        var cellCol = cell.cellIndex;
        minesCount == 0 ? revealAdjacentCells(cellRow, cellCol) : (cell.innerHTML = minesCount);
    }
}

function revealAdjacentCells(cellRow, cellCol) {
    for (var i = Math.max(cellRow - 1, 0); i <= Math.min(cellRow + 1, 9); i++) {
        for (var j = Math.max(cellCol - 1, 0); j <= Math.min(cellCol + 1, 9); j++) {
            var adjacentCell = grid.rows[i].cells[j];
            if (adjacentCell.innerHTML == "" && !adjacentCell.classList.contains("clicked")) {
                clickCell(adjacentCell);
            }
        }
    }
}


function checkCompletion() {
    var flaggedMines = 0;

    for (var i = 0; i < minesLocations.length; i++) {
        var mineLocation = minesLocations[i];
        var cell = grid.rows[mineLocation.row].cells[mineLocation.column];

        if (cell.getAttribute("mine") == "true" && cell.innerHTML == "🚩") {
            flaggedMines++;
        }
        
    }

    if (flaggedMines == minesLocations.length && flaggedMines == flagsCount) {
        alert("Congratulations You've Won!")
    }
}



function countNearbyMines(cell) {
    var minesCount = 0;
    var cellRow = cell.parentNode.rowIndex;
    var cellCol = cell.cellIndex;

    for (var i = Math.max(cellRow - 1, 0); i <= Math.min(cellRow + 1, 9); i++) {
        for (var j = Math.max(cellCol - 1, 0); j <= Math.min(cellCol + 1, 9); j++) {
            if (grid.rows[i].cells[j].getAttribute("mine") == "true") {
                minesCount++;
            }
        }
    }
    return minesCount;
}

function revealMines() {
    for (var i = 0; i < 10; i++) {
        for (var j = 0; j < 10; j++) {
            var cell = grid.rows[i].cells[j];

            if (cell.getAttribute("mine") == "true") {
                cell.className = "mine";
            }
        }
    }
}

function toggleFlag(cell) {
    if (cell.getAttribute("flag") == "true") {
        cell.setAttribute("flag", "false");
        cell.innerHTML = "";
        flagsCount--;
    } else {
        cell.setAttribute("flag", "true");
        cell.innerHTML = "🚩";
        flagsCount++;
    }
    checkCompletion();
}


generateGrid();

