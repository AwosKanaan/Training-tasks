var password_characters = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";

function generatePassword() {
    var password_length = 12;
    var password = "";
    for (var i = 0; i < password_length; i++) { // Changed "<=" to "<" to generate the correct length
        var randomNumber = Math.floor(Math.random() * password_characters.length); // Corrected variable name
        password += password_characters.charAt(randomNumber); // Corrected variable name
    }
    return password;
}

var generate_button = document.getElementById("password");

generate_button.addEventListener("click", function() {
    var input = document.querySelector(".input"); 
    var randomPassword = generatePassword();
    input.value = randomPassword;
});